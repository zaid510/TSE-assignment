package crs;

public interface StudentInterface {
	static void viewAllCourses() {};
	
	static void viewFullCourses() {};
	
	static void register() {};
	
	static void withdraw() {};
	
	static void viewYourCourses() {};
}

