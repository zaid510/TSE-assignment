# course-registration-system
System that allows student/admin login for managing and registering for university courses.
Student and Course information is stored in a serialized file for recalling information after exiting the program.
